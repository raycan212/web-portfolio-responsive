/*===== MENU SHOW =====*/ 

/*===== REMOVE MENU MOBILE =====*/

/*===== SCROLL SECTIONS ACTIVE LINK =====*/

/*===== SCROLL REVEAL ANIMATION =====*/

/*SCROLL HOME*/

/*SCROLL ABOUT*/

/*SCROLL SKILLS*/

/*SCROLL PORTFOLIO*/

/*SCROLL CONTACT*/



